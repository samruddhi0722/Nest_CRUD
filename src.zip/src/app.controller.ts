/* eslint-disable prettier/prettier */
import { Controller, Get } from '@nestjs/common';
import { Header } from '@nestjs/common/decorators';
import { AppService } from './app.service';

@Controller()
export class AppController {
  static getHello: any;
  constructor(private readonly appService: AppService) {}

  @Get()
  @Header('Content-Type','text/html')
  getHello(): {name:string} {
    return {name:'Max'};
  }
}
